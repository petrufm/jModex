package testsessionattribute.test1;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Entry extends org.apache.jasper.runtime.HttpJspBase implements org.apache.jasper.runtime.JspSourceDependent {

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {
		testDynamicAttribute1(request,"someAttribute","aValue");
		response.getOutputStream().println((String) request.getSession().getAttribute("someAttribute"));
	}
		
	public void testDynamicAttribute1(HttpServletRequest request, String x, String y) {
		request.getSession().setAttribute(x,y);
	}
	
	@Override
	public Object getDependants() {
		return null;
	}

}
