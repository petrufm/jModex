package interproc.testparam1;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Entry extends org.apache.jasper.runtime.HttpJspBase implements org.apache.jasper.runtime.JspSourceDependent {

	
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {
		caller(request);
	}
	
	public static int caller(HttpServletRequest request) {
		return foo(request,"name");
	}
	
	public static int foo(HttpServletRequest request, String param) {
		if(request.getParameter(param).equals("pepi")) {
			return 1;
		} else {
			return 2;
		}
	}
	
	@Override
	public Object getDependants() {
		return null;
	}

}
