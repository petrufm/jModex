package testsubsume.test4;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EntrySubsume4 extends org.apache.jasper.runtime.HttpJspBase implements org.apache.jasper.runtime.JspSourceDependent {
	
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {
		testsubsume4(request);
		response.getOutputStream().println("Out");
	}
		
	public int testsubsume4(HttpServletRequest r) {
		int i;
		if(r.getParameter("reqPar").equals("something")) {
			i = 0;
		} else {
			i = 1;
		}
		return i;
	}
	
	@Override
	public Object getDependants() {
		return null;
	}

}
