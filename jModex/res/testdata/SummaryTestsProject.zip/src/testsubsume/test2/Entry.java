package testsubsume.test2;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Entry extends org.apache.jasper.runtime.HttpJspBase implements org.apache.jasper.runtime.JspSourceDependent {

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {
		testsubsume2(request); 
	}
		
	public static void testsubsume2(HttpServletRequest r) {
		String b;
		if(System.currentTimeMillis() > 0) {
			b = "1";
		} else {
			b = "2";
		}
		r.getSession().setAttribute("cucu", "mumu");
	}
	
	@Override
	public Object getDependants() {
		return null;
	}

}
