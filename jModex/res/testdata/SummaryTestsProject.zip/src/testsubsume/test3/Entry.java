package testsubsume.test3;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Entry extends org.apache.jasper.runtime.HttpJspBase implements org.apache.jasper.runtime.JspSourceDependent {

	private static String D;
	
	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {
		D = testsubsume3(request); 
	}
		
	public String testsubsume3(HttpServletRequest r) {
		String b;
		if(System.currentTimeMillis() > 0) {
			b = "1";
		} else {
			b = "2";
		}
		r.getSession().setAttribute("cucu", "mumu");
		return b;
	}
	
	@Override
	public Object getDependants() {
		return null;
	}

}
