package testloops.test11;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Entry extends org.apache.jasper.runtime.HttpJspBase implements org.apache.jasper.runtime.JspSourceDependent {

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {
		String action = request.getParameter("action");
		if(action.equals("test1")) {
			test(request);
		}
		if(action.equals("test2")) {
			request.getSession().setAttribute("attr2", "da");			
		}
	}
		
	public void test(HttpServletRequest request) {
		for(int i = 0; i < 1; i++) {
			request.getSession().setAttribute("attr1", "da");
		}		
	}
	
	@Override
	public Object getDependants() {
		return null;
	}

}
