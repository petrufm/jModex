package testloops.test1;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Entry extends org.apache.jasper.runtime.HttpJspBase implements org.apache.jasper.runtime.JspSourceDependent {

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {
		foo(1,2); 
	}
		
	public static int foo(int x, int y) {
		if(x < 0) {
			return y;
		}
		for(int i = x; i > 0; i--) {
			y = y - 1;
		}
		return y;
	}
	
	@Override
	public Object getDependants() {
		return null;
	}

}
