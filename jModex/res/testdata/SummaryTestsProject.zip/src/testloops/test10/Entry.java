package testloops.test10;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Entry extends org.apache.jasper.runtime.HttpJspBase implements org.apache.jasper.runtime.JspSourceDependent {

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {
		testNestedLoopContinueSpecial1(1,2); 
	}
		
	public int testNestedLoopContinueSpecial1(int x, int y) {
		A:for(int i = 0; i < x; i++) {
			for(int j = 0; j < y; j++) {
				if(i + j > 100) continue A;
				y = y + 1;
			}
			y = y + 1000;
		}
		return y;
	}
	
	@Override
	public Object getDependants() {
		return null;
	}

}
