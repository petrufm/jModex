package testloops.test6;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Entry extends org.apache.jasper.runtime.HttpJspBase implements org.apache.jasper.runtime.JspSourceDependent {

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {
		testLoopReturn(-10); 
	}
		
	public int testLoopReturn(int a) {
		for(int i = 0; i < 100; i++) {
			a++;
			if(a == 10) return a;
		}
		return a;
	}
	
	@Override
	public Object getDependants() {
		return null;
	}

}
