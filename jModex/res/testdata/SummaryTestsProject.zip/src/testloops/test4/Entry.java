package testloops.test4;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Entry extends org.apache.jasper.runtime.HttpJspBase implements org.apache.jasper.runtime.JspSourceDependent {

	public void _jspService(HttpServletRequest request, HttpServletResponse response) throws java.io.IOException, ServletException {
		testLoopReturnInNestedLoop1(-10); 
	}
		
	public int testLoopReturnInNestedLoop1(int a) {
		for(int i = 0; i < 100; i++) {
			for(int j = 0; j < 1000; j++) {
				a++;
				if(a == 10) return a;				
			}
		}
		return a;
	}
	
	@Override
	public Object getDependants() {
		return null;
	}

}
